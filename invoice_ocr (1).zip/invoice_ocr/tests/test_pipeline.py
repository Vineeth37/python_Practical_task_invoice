"""Tests use fixed OCR text so they do not depend on the installed OCR version.
The last two tests run real OCR on generated images and are skipped without Tesseract."""
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

from invoice_pipeline import db
from invoice_pipeline.money import format_minor, parse_amount
from invoice_pipeline.parse import extract_fields, parse_date
from invoice_pipeline.pipeline import process_text, run
from invoice_pipeline.validate import validate

ROOT = Path(__file__).resolve().parent.parent

VALID_TEXT = """TAX INVOICE
Vendor: Sharma Office Supplies Pvt Ltd
Invoice No: INV-101
Invoice Date: 05/11/2026
Due Date: 20/11/2026
Subtotal: INR 10,000.00
GST (18%): INR 1,800.00
Total: INR 11,800.00
"""


@pytest.fixture
def conn(tmp_path):
    c = db.connect(str(tmp_path / "test.db"))
    yield c
    c.close()


def count(conn, table):
    return conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]


# 1. valid-field extraction and validation ------------------------------------------------

def test_valid_invoice_is_extracted_normalized_and_valid():
    ex = extract_fields(VALID_TEXT)
    assert ex.invoice_number == "INV-101"
    assert ex.vendor == "Sharma Office Supplies Pvt Ltd"
    assert ex.invoice_date == "2026-11-05"          # Due Date must not be picked
    assert ex.currency == "INR"
    assert (ex.subtotal_minor, ex.tax_minor, ex.total_minor) == (1_000_000, 180_000, 1_180_000)
    assert all(isinstance(v, int) for v in (ex.subtotal_minor, ex.tax_minor, ex.total_minor))
    assert validate(ex, ocr_confidence=90) == []


def test_total_mismatch_is_flagged_not_fixed():
    ex = extract_fields(VALID_TEXT.replace("11,800.00", "11,900.00"))
    reasons = validate(ex)
    assert len(reasons) == 1 and reasons[0].startswith("total_mismatch")
    assert ex.total_minor == 1_190_000               # kept as read, not "corrected"


def test_amount_and_date_normalization():
    assert parse_amount("₹ 1,00,000.50") == 10_000_050   # Indian digit grouping
    assert parse_amount("Rs. 99") == 9900
    assert parse_amount("1.180,00") is None              # ambiguous separators: refuse
    assert format_minor(295059) == "2950.59"
    assert parse_date("12 Nov 2026")[0] == "2026-11-12"
    assert parse_date("Nov 12, 2026")[0] == "2026-11-12"
    assert parse_date("2026-11-12")[0] == "2026-11-12"
    assert parse_date("31/02/2026")[0] is None            # impossible date


# 2. duplicate / repeated import -------------------------------------------------------------

def test_repeated_run_and_second_scan_do_not_duplicate_invoices(conn):
    first = process_text(conn, "a.png", "sha-a", VALID_TEXT, 95)
    assert first["outcome"] == "imported"

    again = process_text(conn, "a.png", "sha-a", VALID_TEXT, 95)          # same dir, second run
    assert again["outcome"] == "already_imported"

    # a different scan of the same invoice (different bytes + slightly different OCR text)
    copy = process_text(conn, "a-copy.png", "sha-b", VALID_TEXT.replace("Pvt Ltd", "PVT LTD"), 90)
    assert copy["outcome"] == "duplicate_scan"

    assert count(conn, "invoices") == 1
    assert count(conn, "scans") == 2                       # both scans stay traceable
    assert sorted(copy["linked_scans"]) == ["a-copy.png", "a.png"]


def test_same_invoice_number_with_different_amounts_goes_to_review(conn):
    process_text(conn, "a.png", "sha-a", VALID_TEXT, 95)
    other = (VALID_TEXT.replace("Subtotal: INR 10,000.00", "Subtotal: INR 20,000.00")
                       .replace("GST (18%): INR 1,800.00", "GST (18%): INR 3,600.00")
                       .replace("Total: INR 11,800.00", "Total: INR 23,600.00"))
    result = process_text(conn, "b.png", "sha-b", other, 95)
    assert result["status"] == "needs_review"
    assert result["review_reasons"][0].startswith("duplicate_key_conflict")
    assert count(conn, "invoices") == 1


def test_db_rejects_inconsistent_money_even_if_code_is_wrong(conn):
    with pytest.raises(sqlite3.IntegrityError):
        conn.execute(
            "INSERT INTO invoices (vendor, vendor_key, invoice_number, invoice_key, invoice_date,"
            " currency, subtotal_minor, tax_minor, total_minor, created_at)"
            " VALUES ('V','v','1','1','2026-01-01','INR',100,10,999,'now')")


# 3. incomplete / ambiguous input -------------------------------------------------------------

def test_incomplete_and_ambiguous_record_is_reviewed_with_reasons(conn):
    text = """INVOICE
Invoice No: INV-103
Invoice Date: 14/11/2026
Subtotal: INR 5,000.00
Total: INR 5,900.00
Total: INR 5,950.00
"""
    result = process_text(conn, "103.png", "sha-103", text, 95)
    reasons = " | ".join(result["review_reasons"])
    assert result["status"] == "needs_review"
    assert "missing_vendor" in reasons
    assert "missing_tax" in reasons
    assert "ambiguous_total" in reasons and "5900.00" in reasons and "5950.00" in reasons
    assert result["extracted"]["total"] is None            # not guessed
    assert count(conn, "invoices") == 0
    stored = conn.execute("SELECT status, raw_ocr_text FROM scans").fetchone()
    assert stored["status"] == "needs_review" and "INV-103" in stored["raw_ocr_text"]


def test_low_ocr_confidence_goes_to_review(conn):
    result = process_text(conn, "x.png", "sha-x", VALID_TEXT, 31, min_confidence=50)
    assert result["status"] == "needs_review"
    assert result["review_reasons"][0].startswith("low_ocr_confidence")


def test_conflicting_currencies_are_ambiguous():
    ex = extract_fields(VALID_TEXT + "Paid via USD wire\n")
    assert any(i.startswith("ambiguous_currency") for i in ex.issues)


# 4. real OCR, end to end -----------------------------------------------------------------

needs_tesseract = pytest.mark.skipif(shutil.which("tesseract") is None, reason="tesseract not installed")


@pytest.fixture
def images(tmp_path):
    d = tmp_path / "images"
    subprocess.run([sys.executable, str(ROOT / "tools" / "make_synthetic_fixtures.py"), str(d)],
                   check=True, capture_output=True)
    return d


@needs_tesseract
def test_end_to_end_twice_and_bad_file_does_not_stop_batch(images, tmp_path):
    (images / "broken.png").write_bytes(b"not an image")
    args = (str(images), str(tmp_path / "e2e.db"), str(tmp_path / "out"))

    first = run(*args)
    outcomes = {r["source_file"]: r["outcome"] for r in first["records"]}
    assert outcomes["broken.png"] == "error"
    assert outcomes["invoice-103-review.png"] == "needs_review"
    assert sorted(o for o in outcomes.values() if o in ("imported", "duplicate_scan")) == \
        ["duplicate_scan", "imported", "imported"]

    second = run(*args)
    assert second["summary"].get("imported", 0) == 0       # nothing new inserted
    c = sqlite3.connect(tmp_path / "e2e.db")
    assert c.execute("SELECT COUNT(*) FROM invoices").fetchone()[0] == 2
    assert (tmp_path / "out" / "report.json").exists() and (tmp_path / "out" / "report.csv").exists()
    assert (tmp_path / "out" / "ocr_text" / "invoice-101.png.txt").read_text().strip()


# 5. regression: label format of the official fixtures ("Invoice: TNM-101", "Date: [not supplied]")

def test_plain_invoice_label_and_unreadable_date_and_total():
    text = """SYNTHETIC TEST INVOICE
Invoice: TNM-103
Vendor: Gamma Paper Co
Date: [not supplied]
Currency: INR
Subtotal: 1000.00
Tax: 180.00
Total: 11?0.00
"""
    ex = extract_fields(text)
    assert ex.invoice_number == "TNM-103"
    assert ex.invoice_date is None and "missing_invoice_date" in ex.issues
    assert ex.total_minor is None and "missing_total" in ex.issues   # '?' must not be read as 11.00

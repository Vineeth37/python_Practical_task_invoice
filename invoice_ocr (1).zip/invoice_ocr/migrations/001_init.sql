-- Money is stored as INTEGER minor units (paise/cents) - never floating point.

CREATE TABLE invoices (
    id               INTEGER PRIMARY KEY,
    vendor           TEXT    NOT NULL,
    vendor_key       TEXT    NOT NULL,  -- lowercase, punctuation stripped
    invoice_number   TEXT    NOT NULL,
    invoice_key      TEXT    NOT NULL,  -- uppercase alphanumerics only
    invoice_date     TEXT    NOT NULL,  -- ISO 8601
    currency         TEXT    NOT NULL,
    subtotal_minor   INTEGER NOT NULL CHECK (subtotal_minor >= 0),
    tax_minor        INTEGER NOT NULL CHECK (tax_minor >= 0),
    total_minor      INTEGER NOT NULL CHECK (total_minor >= 0),
    created_at       TEXT    NOT NULL,
    -- Duplicate key: invoice numbers are only unique per vendor.
    UNIQUE (vendor_key, invoice_key),
    CHECK (subtotal_minor + tax_minor = total_minor)
);

-- One row per distinct scanned file (identified by content hash), whatever its outcome.
CREATE TABLE scans (
    id               INTEGER PRIMARY KEY,
    source_filename  TEXT    NOT NULL,
    sha256           TEXT    NOT NULL,
    raw_ocr_text     TEXT,
    ocr_confidence   REAL,
    status           TEXT    NOT NULL CHECK (status IN ('valid', 'needs_review', 'error')),
    review_reasons   TEXT,              -- JSON array
    invoice_id       INTEGER REFERENCES invoices(id),
    processed_at     TEXT    NOT NULL,
    -- Same bytes under two filenames still get two rows (traceability); reruns upsert.
    UNIQUE (source_filename, sha256)
);

CREATE INDEX idx_scans_invoice ON scans(invoice_id);
CREATE INDEX idx_invoices_date ON invoices(invoice_date);

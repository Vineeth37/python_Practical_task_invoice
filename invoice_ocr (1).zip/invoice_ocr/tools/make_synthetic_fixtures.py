"""Generate SYNTHETIC invoice images for local testing (not the official assignment fixtures).

    python tools/make_synthetic_fixtures.py synthetic_fixtures
"""
import random
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

INVOICES = {
    "invoice-101.png": [
        "TAX INVOICE",
        "Vendor: Sharma Office Supplies Pvt Ltd",
        "Invoice No: INV-101",
        "Invoice Date: 05/11/2026",
        "Due Date: 20/11/2026",
        "Item: Printer paper x 10        INR 4,000.00",
        "Subtotal: INR 10,000.00",
        "GST (18%): INR 1,800.00",
        "Total: INR 11,800.00",
    ],
    "invoice-102.png": [
        "INVOICE",
        "Vendor: Delhi Print House",
        "Invoice Number: DPH/2026/102",
        "Invoice Date: 12 Nov 2026",
        "Subtotal: INR 2,500.50",
        "Tax: INR 450.09",
        "Total: INR 2,950.59",
    ],
    # incomplete / ambiguous: no vendor, no tax line, two different totals
    "invoice-103-review.png": [
        "INVOICE",
        "Invoice No: INV-103",
        "Invoice Date: 14/11/2026",
        "Subtotal: INR 5,000.00",
        "Total: INR 5,900.00",
        "Total: INR 5,950.00",
    ],
}


def render(lines, size=(1100, 650), font_px=30):
    img = Image.new("RGB", size, "white")
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype(FONT, font_px)
    y = 40
    for line in lines:
        draw.text((50, y), line, fill="black", font=font)
        y += font_px + 22
    return img


def main(out: str) -> None:
    out_dir = Path(out)
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, lines in INVOICES.items():
        render(lines).save(out_dir / name)
    # Second scan of invoice 101: different size, slight rotation, blur and noise.
    random.seed(7)
    scan = render(INVOICES["invoice-101.png"], size=(1000, 600), font_px=27)
    scan = scan.rotate(0.8, expand=True, fillcolor="white").filter(ImageFilter.GaussianBlur(0.6))
    px = scan.load()
    for _ in range(1500):
        x, y = random.randrange(scan.width), random.randrange(scan.height)
        v = random.randrange(120, 255)
        px[x, y] = (v, v, v)
    scan.save(out_dir / "invoice-101-copy.png")
    print(f"wrote {len(INVOICES) + 1} images to {out_dir}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "synthetic_fixtures")

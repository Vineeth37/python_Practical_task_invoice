"""SQLite storage: migrations, duplicate-safe import, scan traceability."""
from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .money import format_minor
from .parse import Extracted

MIGRATIONS = Path(__file__).resolve().parent.parent / "migrations"


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, isolation_level=None)  # explicit transactions below
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    migrate(conn)
    return conn


def migrate(conn: sqlite3.Connection) -> None:
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    for f in sorted(MIGRATIONS.glob("*.sql")):
        n = int(f.name.split("_")[0])
        if n > version:
            conn.executescript(f"BEGIN;\n{f.read_text()}\nPRAGMA user_version = {n};\nCOMMIT;")


def vendor_key(vendor: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", vendor.lower()).strip()


def invoice_key(number: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", number.upper())


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


_UPSERT_SCAN = """
INSERT INTO scans (source_filename, sha256, raw_ocr_text, ocr_confidence, status,
                   review_reasons, invoice_id, processed_at)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT (source_filename, sha256) DO UPDATE SET
    raw_ocr_text = excluded.raw_ocr_text, ocr_confidence = excluded.ocr_confidence,
    status = excluded.status, review_reasons = excluded.review_reasons,
    invoice_id = excluded.invoice_id, processed_at = excluded.processed_at
"""


def record_result(conn: sqlite3.Connection, filename: str, sha: str, raw_text: str,
                  confidence: float | None, ex: Extracted, reasons: list[str]) -> dict:
    """Store one scan (and its invoice when valid) atomically.

    outcome: imported | already_imported | duplicate_scan | needs_review
    """
    reasons = list(reasons)
    invoice_id, outcome = None, "needs_review"
    conn.execute("BEGIN IMMEDIATE")
    try:
        if not reasons:
            vkey, ikey = vendor_key(ex.vendor), invoice_key(ex.invoice_number)
            row = conn.execute(
                "SELECT * FROM invoices WHERE vendor_key = ? AND invoice_key = ?", (vkey, ikey)
            ).fetchone()
            values = (ex.invoice_date, ex.currency, ex.subtotal_minor, ex.tax_minor, ex.total_minor)
            if row is None:
                cur = conn.execute(
                    """INSERT INTO invoices (vendor, vendor_key, invoice_number, invoice_key,
                           invoice_date, currency, subtotal_minor, tax_minor, total_minor, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (ex.vendor, vkey, ex.invoice_number, ikey, *values, _now()),
                )
                invoice_id, outcome = cur.lastrowid, "imported"
            elif (row["invoice_date"], row["currency"], row["subtotal_minor"],
                  row["tax_minor"], row["total_minor"]) == values:
                invoice_id = row["id"]
                seen = conn.execute(
                    "SELECT 1 FROM scans WHERE source_filename = ? AND sha256 = ? AND invoice_id = ?",
                    (filename, sha, invoice_id),
                ).fetchone()
                outcome = "already_imported" if seen else "duplicate_scan"
            else:
                reasons.append(
                    f"duplicate_key_conflict: invoice {ex.invoice_number} from {ex.vendor} is already "
                    f"stored (id {row['id']}, total {format_minor(row['total_minor'])}) with different "
                    f"values (this scan: total {format_minor(ex.total_minor)})"
                )
        conn.execute(_UPSERT_SCAN, (
            filename, sha, raw_text, confidence,
            "valid" if invoice_id else "needs_review",
            json.dumps(reasons), invoice_id, _now(),
        ))
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    return {"outcome": outcome, "invoice_id": invoice_id, "review_reasons": reasons}


def record_error(conn: sqlite3.Connection, filename: str, sha: str, message: str) -> None:
    conn.execute("BEGIN IMMEDIATE")
    try:
        conn.execute(_UPSERT_SCAN, (filename, sha, None, None, "error",
                                    json.dumps([message]), None, _now()))
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise


def linked_scans(conn: sqlite3.Connection, invoice_id: int) -> list[str]:
    rows = conn.execute(
        "SELECT source_filename FROM scans WHERE invoice_id = ? ORDER BY id", (invoice_id,))
    return [r[0] for r in rows]

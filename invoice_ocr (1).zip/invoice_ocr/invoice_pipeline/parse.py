"""Extract invoice fields from raw OCR text.

Rules: never guess. If a field is missing, or the text contains several different
candidate values for it, the field is left empty and an issue is recorded so the
record goes to `needs_review`.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date

from .money import detect_currency, format_minor, parse_amount

FLAGS = re.I | re.M

_CUR = r"(?:₹|rs\.?|inr|usd|us\$|eur|gbp|\$|€|£)"
_SEP = r"[^\S\n]*[:\-]?[^\S\n]*"
_UNIT = r"(?:[^\S\n]*\([^)\n]{1,6}\))?"
_AMOUNT = rf"(?:{_CUR}[^\S\n]*)?(\d[\d,]*(?:\.\d+)?)(?![\w?])"

_PCT = r"(?:[^\S\n]*[(@]?[^\S\n]*\d+(?:\.\d+)?[^\S\n]*%\)?)?"

LABELS = {
    "subtotal": r"sub[\s\-]*total",
    "total": r"(?<!sub)(?<!sub )(?<!sub-)(?:grand\s+total|total\s+(?:amount|due|payable)|amount\s+(?:due|payable)|total)",
    "tax": rf"(?:total\s+)?(?:tax|gst|vat|igst){_PCT}",
    "cgst": rf"cgst{_PCT}",
    "sgst": rf"sgst{_PCT}",
}

_INVOICE_NO = re.compile(
    r"(?<![A-Za-z])invoice(?:[^\S\n]*(?:no\.?|number|num\.?|#)(?![A-Za-z])|(?=[^\S\n]*:))"
    r"[^\S\n]*[:\-#.]*[^\S\n]*"
    r"([A-Za-z0-9][A-Za-z0-9\-/_.]*)",
    FLAGS,
)
_VENDOR = re.compile(
    r"(?<![A-Za-z])(?:vendor(?:[^\S\n]*name)?|supplier(?:[^\S\n]*name)?|seller|billed[^\S\n]*by|sold[^\S\n]*by|from)"
    r"[^\S\n]*[:\-][^\S\n]*([^\n]+)",
    FLAGS,
)
_DATE_LABEL = re.compile(
    r"(?<![A-Za-z])(due[^\S\n]+)?(invoice[^\S\n]*date|issue[^\S\n]*date|date[^\S\n]+of[^\S\n]+issue|dated|date)\b[^\S\n]*[:\-]?",
    FLAGS,
)

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], start=1)}

_D_ISO = re.compile(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b")
_D_NUM = re.compile(r"\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})\b")
_D_DMY_NAME = re.compile(r"\b(\d{1,2})(?:st|nd|rd|th)?[\s\-]+([A-Za-z]{3,9})\.?,?[\s\-]+(\d{4})\b")
_D_MDY_NAME = re.compile(r"\b([A-Za-z]{3,9})\.?[\s\-]+(\d{1,2})(?:st|nd|rd|th)?,?[\s\-]+(\d{4})\b")


@dataclass
class Extracted:
    invoice_number: str | None = None
    vendor: str | None = None
    invoice_date: str | None = None          # ISO 8601
    currency: str | None = None
    subtotal_minor: int | None = None
    tax_minor: int | None = None
    total_minor: int | None = None
    issues: list[str] = field(default_factory=list)    # reasons for needs_review
    warnings: list[str] = field(default_factory=list)  # recorded but not blocking

    def as_dict(self) -> dict:
        return {
            "invoice_number": self.invoice_number,
            "vendor": self.vendor,
            "invoice_date": self.invoice_date,
            "currency": self.currency,
            "subtotal": format_minor(self.subtotal_minor),
            "tax": format_minor(self.tax_minor),
            "total": format_minor(self.total_minor),
        }


def _valid_date(y: int, m: int, d: int) -> str | None:
    try:
        return date(y, m, d).isoformat()
    except ValueError:
        return None


def parse_date(segment: str, dayfirst: bool = True) -> tuple[str | None, str | None]:
    """Find the first date in `segment`. Returns (iso_date, warning)."""
    candidates: list[tuple[int, str, str | None]] = []
    for m in _D_ISO.finditer(segment):
        iso = _valid_date(int(m[1]), int(m[2]), int(m[3]))
        if iso:
            candidates.append((m.start(), iso, None))
    for m in _D_NUM.finditer(segment):
        a, b, y = int(m[1]), int(m[2]), int(m[3])
        dmy, mdy = _valid_date(y, b, a), _valid_date(y, a, b)
        warn = None
        if dmy and mdy and dmy != mdy:
            warn = f"date '{m[0]}' read as {'day-first' if dayfirst else 'month-first'} (both readings valid)"
        iso = (dmy or mdy) if dayfirst else (mdy or dmy)
        if iso:
            candidates.append((m.start(), iso, warn))
    for m in _D_DMY_NAME.finditer(segment):
        mon = MONTHS.get(m[2][:3].lower())
        iso = mon and _valid_date(int(m[3]), mon, int(m[1]))
        if iso:
            candidates.append((m.start(), iso, None))
    for m in _D_MDY_NAME.finditer(segment):
        mon = MONTHS.get(m[1][:3].lower())
        iso = mon and _valid_date(int(m[3]), mon, int(m[2]))
        if iso:
            candidates.append((m.start(), iso, None))
    if not candidates:
        return None, None
    _, iso, warn = min(candidates, key=lambda c: c[0])
    return iso, warn


def _amounts(text: str, label: str) -> list[int]:
    out: list[int] = []
    pattern = re.compile(rf"(?<![A-Za-z]){label}\b{_UNIT}{_SEP}{_AMOUNT}", FLAGS)
    for m in pattern.finditer(text):
        minor = parse_amount(m.group(m.lastindex))
        if minor is not None:
            out.append(minor)
    return out


def _pick(name: str, values: list, ex: Extracted, show=lambda v: str(v)):
    distinct = list(dict.fromkeys(values))
    if not distinct:
        ex.issues.append(f"missing_{name}")
        return None
    if len(distinct) > 1:
        ex.issues.append(f"ambiguous_{name}: found {', '.join(show(v) for v in distinct)}")
        return None
    return distinct[0]


def extract_fields(text: str, dayfirst: bool = True) -> Extracted:
    ex = Extracted()

    nums = [m[1].strip(".,") for m in _INVOICE_NO.finditer(text)]
    nums = [n for n in nums if any(c.isdigit() for c in n)]
    ex.invoice_number = _pick("invoice_number", [n.upper() for n in nums], ex)

    vendors: list[str] = []
    for m in _VENDOR.finditer(text):
        v = re.split(r"\s{2,}", m[1].strip())[0].strip(" .,|:-")
        if len(v) >= 2 and re.search(r"[A-Za-z]", v):
            vendors.append(v)
    keyed = {re.sub(r"[^a-z0-9]+", " ", v.lower()).strip(): v for v in vendors}
    picked = _pick("vendor", list(keyed), ex)
    ex.vendor = keyed[picked] if picked else None

    dates: list[str] = []
    for m in _DATE_LABEL.finditer(text):
        if m[1]:  # "Due Date" is not the invoice date
            continue
        line_end = text.find("\n", m.end())
        segment = text[m.end(): line_end if line_end != -1 else len(text)]
        iso, warn = parse_date(segment, dayfirst)
        if iso:
            dates.append(iso)
            if warn:
                ex.warnings.append(warn)
    ex.invoice_date = _pick("invoice_date", dates, ex)

    code, found = detect_currency(text)
    if len(found) > 1:
        ex.issues.append(f"ambiguous_currency: found {', '.join(found)}")
    elif not found:
        ex.issues.append("missing_currency")
    ex.currency = code

    ex.subtotal_minor = _pick("subtotal", _amounts(text, LABELS["subtotal"]), ex, lambda v: format_minor(v))

    tax_vals = _amounts(text, LABELS["tax"])
    if not tax_vals:
        cg, sg = _amounts(text, LABELS["cgst"]), _amounts(text, LABELS["sgst"])
        if len(set(cg)) == 1 and len(set(sg)) == 1:
            tax_vals = [cg[0] + sg[0]]
            ex.warnings.append("tax computed as CGST + SGST")
    ex.tax_minor = _pick("tax", tax_vals, ex, lambda v: format_minor(v))

    ex.total_minor = _pick("total", _amounts(text, LABELS["total"]), ex, lambda v: format_minor(v))
    return ex

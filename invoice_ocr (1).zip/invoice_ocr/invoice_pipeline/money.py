"""Money helpers. Amounts are integer minor units (paise/cents), never floats."""
from __future__ import annotations

import re
from decimal import Decimal

_CURRENCY_PATTERNS = [
    (re.compile(r"₹|\bRs\b\.?|\bINR\b", re.I), "INR"),
    (re.compile(r"\bUSD\b|\bUS\$|\$"), "USD"),
    (re.compile(r"€|\bEUR\b", re.I), "EUR"),
    (re.compile(r"£|\bGBP\b", re.I), "GBP"),
]

_CURRENCY_STRIP = re.compile(r"₹|\bRs\b\.?|\bINR\b|\bUSD\b|\bUS\$|\$|€|\bEUR\b|£|\bGBP\b", re.I)
# 1234.50 | 1,234.50 | 1,00,000.00 (Indian grouping) | 1234
_AMOUNT_OK = re.compile(r"^(?:\d+|\d{1,3}(?:,\d{2,3})+)(?:\.\d{1,2})?$")


def detect_currency(text: str) -> tuple[str | None, list[str]]:
    """Return (currency, all_codes_found). Several different codes => ambiguous."""
    found: list[str] = []
    for pattern, code in _CURRENCY_PATTERNS:
        if pattern.search(text) and code not in found:
            found.append(code)
    return (found[0] if len(found) == 1 else None), found


def parse_amount(raw: str) -> int | None:
    """'₹ 1,180.00' -> 118000. Returns None if the text is not a clean amount."""
    s = _CURRENCY_STRIP.sub("", raw).strip().rstrip(".,")
    s = s.replace(" ", "")
    if not _AMOUNT_OK.match(s):
        return None
    return int((Decimal(s.replace(",", "")) * 100).to_integral_exact())


def format_minor(minor: int | None) -> str | None:
    if minor is None:
        return None
    sign = "-" if minor < 0 else ""
    minor = abs(minor)
    return f"{sign}{minor // 100}.{minor % 100:02d}"

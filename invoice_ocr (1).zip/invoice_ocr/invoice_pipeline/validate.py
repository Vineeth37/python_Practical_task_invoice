"""Validation on top of extraction."""
from __future__ import annotations

from .money import format_minor
from .parse import Extracted

REQUIRED = ["invoice_number", "vendor", "invoice_date", "currency",
            "subtotal_minor", "tax_minor", "total_minor"]


def validate(ex: Extracted, ocr_confidence: float | None = None,
             min_confidence: float = 50.0) -> list[str]:
    """Return the list of review reasons (empty list == valid)."""
    reasons = list(ex.issues)
    if all(getattr(ex, f) is not None for f in ("subtotal_minor", "tax_minor", "total_minor")):
        if ex.subtotal_minor + ex.tax_minor != ex.total_minor:
            reasons.append(
                "total_mismatch: subtotal "
                f"{format_minor(ex.subtotal_minor)} + tax {format_minor(ex.tax_minor)} = "
                f"{format_minor(ex.subtotal_minor + ex.tax_minor)}, but total is {format_minor(ex.total_minor)}"
            )
    if ocr_confidence is not None and ocr_confidence < min_confidence:
        reasons.append(f"low_ocr_confidence: {ocr_confidence:.0f} < {min_confidence:.0f}")
    return reasons

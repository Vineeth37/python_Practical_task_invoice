"""Invoice OCR -> validation -> database pipeline."""

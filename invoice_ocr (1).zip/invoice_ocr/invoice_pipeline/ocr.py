"""OCR step (Tesseract via pytesseract) with light image preprocessing."""
from __future__ import annotations

from PIL import Image, ImageOps
import pytesseract


def check_tesseract() -> str:
    """Raise RuntimeError with install help if Tesseract is not available."""
    try:
        return str(pytesseract.get_tesseract_version())
    except pytesseract.TesseractNotFoundError as exc:
        raise RuntimeError(
            "Tesseract OCR is not installed or not on PATH. Install it "
            "(Ubuntu: sudo apt install tesseract-ocr | macOS: brew install tesseract | "
            "Windows: https://github.com/UB-Mannheim/tesseract/wiki) and retry."
        ) from exc


def preprocess(img: Image.Image) -> Image.Image:
    img = ImageOps.exif_transpose(img).convert("L")
    if img.width < 1400:  # small scans OCR better when upscaled
        scale = 1400 / img.width
        img = img.resize((int(img.width * scale), int(img.height * scale)), Image.LANCZOS)
    return ImageOps.autocontrast(img)


def run_ocr(path: str, lang: str = "eng") -> tuple[str, float | None]:
    """Return (raw_text, mean_word_confidence 0-100)."""
    with Image.open(path) as raw:
        img = preprocess(raw)
    config = "--psm 6"
    text = pytesseract.image_to_string(img, lang=lang, config=config)
    data = pytesseract.image_to_data(img, lang=lang, config=config,
                                     output_type=pytesseract.Output.DICT)
    confs = [float(c) for c, t in zip(data["conf"], data["text"])
             if t.strip() and float(c) >= 0]
    return text, (sum(confs) / len(confs) if confs else None)

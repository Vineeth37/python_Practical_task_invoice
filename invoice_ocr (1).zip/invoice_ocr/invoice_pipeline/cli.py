"""Command line entry point:  python -m invoice_pipeline --input-dir fixtures"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .ocr import check_tesseract
from .pipeline import run


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="invoice_pipeline",
                                description="OCR invoice images -> validate -> SQLite -> review report")
    p.add_argument("--input-dir", required=True, help="directory containing invoice images")
    p.add_argument("--db", default="invoices.db", help="SQLite database file (default: invoices.db)")
    p.add_argument("--out-dir", default="output", help="where report.json/report.csv/ocr_text go")
    p.add_argument("--min-confidence", type=float, default=50.0,
                   help="mean OCR confidence below this goes to review (default: 50)")
    p.add_argument("--month-first", action="store_true",
                   help="read ambiguous numeric dates as MM/DD/YYYY (default: DD/MM/YYYY)")
    p.add_argument("--lang", default="eng", help="Tesseract language (default: eng)")
    args = p.parse_args(argv)

    if not Path(args.input_dir).is_dir():
        print(f"error: input directory not found: {args.input_dir}", file=sys.stderr)
        return 2
    try:
        check_tesseract()
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 3

    report = run(args.input_dir, args.db, args.out_dir, args.min_confidence,
                 dayfirst=not args.month_first, lang=args.lang)

    for r in report["records"]:
        e = r["extracted"]
        line = f"{r['source_file']:<28} {r['outcome']:<17}"
        if r["status"] == "valid":
            line += f" {e['vendor']} {e['invoice_number']} total {e['currency']} {e['total']}"
        else:
            line += " " + "; ".join(r["review_reasons"])
        print(line)
    print("summary:", report["summary"])
    print(f"report: {Path(args.out_dir) / 'report.json'}  |  database: {args.db}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

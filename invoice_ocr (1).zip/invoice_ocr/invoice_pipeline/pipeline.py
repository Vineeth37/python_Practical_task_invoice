"""Orchestration: OCR -> parse -> validate -> store -> report."""
from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from pathlib import Path

from . import db
from .ocr import run_ocr
from .parse import extract_fields
from .validate import validate

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}

CSV_FIELDS = ["source_file", "status", "outcome", "invoice_id", "invoice_number", "vendor",
              "invoice_date", "currency", "subtotal", "tax", "total", "review_reasons",
              "warnings", "ocr_confidence", "linked_scans", "sha256"]


def process_text(conn: sqlite3.Connection, filename: str, sha: str, raw_text: str,
                 confidence: float | None, min_confidence: float = 50.0,
                 dayfirst: bool = True) -> dict:
    """Everything after OCR. Kept separate so tests can feed fixed OCR text."""
    ex = extract_fields(raw_text, dayfirst=dayfirst)
    reasons = validate(ex, confidence, min_confidence)
    stored = db.record_result(conn, filename, sha, raw_text, confidence, ex, reasons)
    linked = db.linked_scans(conn, stored["invoice_id"]) if stored["invoice_id"] else []
    return {
        "source_file": filename,
        "sha256": sha,
        "status": "valid" if stored["invoice_id"] else "needs_review",
        "outcome": stored["outcome"],
        "invoice_id": stored["invoice_id"],
        "extracted": ex.as_dict(),
        "review_reasons": stored["review_reasons"],
        "warnings": ex.warnings,
        "ocr_confidence": None if confidence is None else round(confidence, 1),
        "linked_scans": linked,
    }


def process_file(conn: sqlite3.Connection, path: Path, **kw) -> dict:
    """One image. Any failure becomes an `error` record; it never raises."""
    name, sha = path.name, None
    try:
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        text, conf = run_ocr(str(path), kw.pop("lang", "eng"))
        record = process_text(conn, name, sha, text, conf, **kw)
        record["raw_ocr_text"] = text
        return record
    except Exception as exc:  # noqa: BLE001 - one bad file must not stop the batch
        message = f"{type(exc).__name__}: {exc}"
        if sha:
            try:
                db.record_error(conn, name, sha, message)
            except Exception:  # noqa: BLE001
                pass
        return {"source_file": name, "sha256": sha, "status": "error", "outcome": "error",
                "invoice_id": None, "extracted": {}, "review_reasons": [message],
                "warnings": [], "ocr_confidence": None, "linked_scans": [], "raw_ocr_text": None}


def run(input_dir: str, db_path: str, out_dir: str, min_confidence: float = 50.0,
        dayfirst: bool = True, lang: str = "eng") -> dict:
    files = sorted(p for p in Path(input_dir).iterdir()
                   if p.is_file() and p.suffix.lower() in IMAGE_EXTS)
    conn = db.connect(db_path)
    records = [process_file(conn, p, lang=lang, min_confidence=min_confidence, dayfirst=dayfirst)
               for p in files]
    # Linked scans can grow while the batch runs (original + later copy), so refresh them.
    for r in records:
        if r["invoice_id"]:
            r["linked_scans"] = db.linked_scans(conn, r["invoice_id"])
    conn.close()

    out = Path(out_dir)
    (out / "ocr_text").mkdir(parents=True, exist_ok=True)
    for r in records:
        text = r.pop("raw_ocr_text", None)
        r["raw_ocr_text_file"] = None
        if text is not None:
            rel = f"ocr_text/{r['source_file']}.txt"
            (out / rel).write_text(text, encoding="utf-8")
            r["raw_ocr_text_file"] = rel

    counts: dict[str, int] = {}
    for r in records:
        counts[r["outcome"]] = counts.get(r["outcome"], 0) + 1
    report = {
        "input_dir": str(input_dir),
        "database": str(db_path),
        "summary": {"files": len(records), **counts},
        "records": records,
    }
    (out / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    with open(out / "report.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
        w.writeheader()
        for r in records:
            w.writerow({**r["extracted"], "source_file": r["source_file"], "status": r["status"],
                        "outcome": r["outcome"], "invoice_id": r["invoice_id"],
                        "review_reasons": " | ".join(r["review_reasons"]),
                        "warnings": " | ".join(r["warnings"]),
                        "ocr_confidence": r["ocr_confidence"],
                        "linked_scans": " | ".join(r["linked_scans"]), "sha256": r["sha256"]})
    return report

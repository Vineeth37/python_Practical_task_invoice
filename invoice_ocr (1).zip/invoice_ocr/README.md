# Invoice OCR → Validation → SQLite

A small Python CLI that runs OCR on invoice images, extracts and validates seven fields
(invoice number, vendor, date, currency, subtotal, tax, total), stores valid invoices in SQLite,
and writes a review report. Records it cannot trust go to `needs_review` with a reason.

## Setup

Requires Python 3.10+ and the Tesseract OCR engine.

```bash
# Tesseract
sudo apt install tesseract-ocr          # Ubuntu/Debian
brew install tesseract                  # macOS
# Windows: install from https://github.com/UB-Mannheim/tesseract/wiki and add it to PATH

python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
# put the four invoice images in one directory, e.g. ./fixtures
python -m invoice_pipeline --input-dir fixtures --db invoices.db --out-dir output
```

Options: `--min-confidence 50` (mean OCR confidence below this goes to review), `--month-first`
(read ambiguous `05/11/2026` as MM/DD instead of DD/MM), `--lang eng`.
Exit codes: `0` ok, `2` input dir missing, `3` Tesseract not installed.

Running it again on the same directory inserts nothing new (`already_imported` in the report).

`fixtures/` holds the four supplied invoice images. `synthetic_fixtures/` holds extra images generated
with `python tools/make_synthetic_fixtures.py synthetic_fixtures` (used by the end-to-end test).

## Test

```bash
python -m pytest -q
```

10 tests. Eight use fixed OCR text (valid fields, normalization, total mismatch, repeated import,
second scan, duplicate-key conflict, DB constraint, missing/ambiguous fields, low confidence).
Two run real Tesseract on generated images (skipped if Tesseract is absent), including a corrupt
file to prove one failure does not stop the batch.

## Output

In `--out-dir`:

- `report.json` – per file: status (`valid` / `needs_review` / `error`), outcome, extracted fields,
  review reasons, warnings, OCR confidence, every scan linked to the same invoice, sha256.
- `report.csv` – the same, flat.
- `ocr_text/<file>.txt` – raw OCR text per file (also stored in the `scans` table).

Outcomes: `imported`, `already_imported` (this exact file was stored by an earlier run),
`duplicate_scan` (another scan of an invoice already stored), `needs_review`, `error`.
Which scan counts as the "first" is just processing order (alphabetical), so the re-scan may be
the one reported as `imported`; `linked_scans` lists both either way.
A sample run on the supplied fixtures is in `sample_output/`.

## Design decisions

**Duplicate key = (normalized vendor, normalized invoice number).** Invoice numbers are only unique
within one vendor, so number alone would wrongly merge different vendors' `INV-1`. Vendor is
lowercased with punctuation removed; the number is uppercased and stripped to letters/digits
(`INV-101` == `inv101`). Enforced by a `UNIQUE` constraint, not just application code.
If the key already exists but date/currency/amounts differ, the scan is **not** merged: it goes to
review as `duplicate_key_conflict`.

**Traceability.** `scans` has one row per (filename, sha256) with raw OCR text, confidence, status,
reasons and a link to the invoice, so a duplicate scan stays linked to the stored invoice.

**Money** is integer minor units (paise). A `CHECK (subtotal + tax = total)` backs up the validator.

**Never guess.** Missing field, or several different candidates for one field (for example two
different `Total:` lines), leaves the field empty and records a reason. Tax is never assumed to be
zero when absent. Vendor is never inferred from the first line.

**Isolation.** Each file is processed in its own transaction and `try/except`; failures are
recorded as `error` and the rest continue.

## Assumptions

- Labels like `Invoice No`, `Vendor`/`Supplier`/`Billed by`/`From:`, `Invoice Date`, `Subtotal`,
  `GST`/`Tax`/`VAT`, `Total`/`Grand Total` appear as `Label: value` on one line. "Due Date" is ignored.
- Numeric dates like `05/11/2026` are read day-first (India); this is recorded as a warning when
  the month-first reading would also be valid. Named months and ISO dates are unambiguous.
- Two decimal places for all currencies. Currency comes from a symbol or code in the text
  (₹/Rs/INR, $/USD, €/EUR, £/GBP).
- CGST + SGST is summed as tax only when no plain tax line exists (recorded as a warning).

## Limitations

- Label patterns are tuned to these fixtures plus common variants. Other layouts may need new labels in
  `invoice_pipeline/parse.py` (`LABELS`, `_VENDOR`, `_INVOICE_NO`).
- Tesseract may read an unclear character as a different digit (in `invoice-103-review.png` it read
  `11?0.00` as `1170.00`). The subtotal + tax = total check catches this and sends it to review.
- Rule-based parsing: layouts with tables, labels on a separate line from values, handwriting,
  or multiple invoices per image are not handled (they land in review, not in the database).
- OCR can misread digits (`0`/`O`, `1`/`l`). The subtotal + tax = total check catches many, not all.
- Single-process SQLite; no concurrency tests.

## Where I would add human correction and retries

- **Correction:** a small review UI/CLI that lists `needs_review` scans with the image and OCR text,
  lets a person fix fields, then re-runs validation and inserts through the same `record_result`.
- **Retries:** re-run OCR for low-confidence or invalid scans with other preprocessing
  (threshold, deskew, `--psm 4/6/11`) and keep the best result; retry transient failures with backoff.
- Store per-field confidence from `image_to_data` and flag only the uncertain fields.
- A background queue for large batches, and structured logs per file.
